import React from 'react'
import { useState, useEffect } from "react";
import "./App.css";


const useGraphQLAPI = ( query ) => {
  const [listMovies, setListMovies] = useState([]);
  const [readyForRender, setReadyForRender] = useState(false);
  
  useEffect(() => {
    const fetchData = async() => {
      const response = await fetch( "<YOUR URL TO THE AURA GRAPHQL API" ,
          {
            method : "POST",
            headers : {
              "Content-Type" : "application/json",
              "x-api-key" : "<YOUR API KEY>"
              },
            body: JSON.stringify({query})
            }
        )
      const json = await response.json();
      if (response.status === 200) {
        setListMovies(json);
        setReadyForRender(true);
        }  
    };
    
    fetchData();

  }, [query]);

  return { readyForRender, listMovies};

};
  
function MovieTable() {

  const movieSearchName = "Toy";

  const MOVIES_QUERY = `query {
          movies( options: { limit: 10 }, where: {title_CONTAINS: "` + movieSearchName +  `" } ) {
            movieId
            released
            title
          }
        }
    `;

  const {readyForRender, listMovies} = useGraphQLAPI(MOVIES_QUERY); 
  
  if(readyForRender) {
    return (
    <div className='movies-table-wrapper'>
    <table className='movies-table'>
      <tbody>
      <tr className='movie-header-row'>
              <th className='movie-header'>ID</th>
              <th className='movie-header'>title</th>
              <th className='movie-header'>released</th>
      </tr>
      {listMovies.data.movies.map((val, key) => {
              return (
                  <tr key={key} className='movie-row'>
                      <td className='movie-row-cell'>{val.movieId}</td>
                      <td className='movie-row-cell'>{val.title}</td>
                      <td className='movie-row-cell'>{val.released}</td>
                  </tr>
                  )
                }
              )
            }
        </tbody>
      </table>
    </div>

          );

  } else { return <div>Loading.....</div>};

}

export default MovieTable